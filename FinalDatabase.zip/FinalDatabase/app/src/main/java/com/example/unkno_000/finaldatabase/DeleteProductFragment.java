package com.example.unkno_000.finaldatabase;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class DeleteProductFragment extends Fragment {

    private EditText TxtItemNumber;
    private Button DeleteButton;

    public DeleteProductFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_delete_product, container, false);
        TxtItemNumber = view.findViewById(R.id.delete_name);
        DeleteButton = view.findViewById(R.id.delete_product);

        DeleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int itemNumber = Integer.parseInt(TxtItemNumber.getText().toString());
                Product product = new Product();
                product.setItemNumber(itemNumber);
                MainActivity.productDatabase.productDao().deleteProduct(product);

                Toast.makeText(getActivity(),"User successfully removed...",Toast.LENGTH_SHORT).show();
                TxtItemNumber.setText("");
            }
        });
        return view;
    }

}
