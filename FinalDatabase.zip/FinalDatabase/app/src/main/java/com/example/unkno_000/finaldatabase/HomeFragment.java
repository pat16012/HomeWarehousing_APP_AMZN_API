package com.example.unkno_000.finaldatabase;


import android.arch.persistence.room.Delete;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

//This is for the physical implementation for this app.
/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment implements View.OnClickListener{

    private Button AddButton,ViewButton, DeleteButton, UpdateButton; //buttons for the app

    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        //listens for add button to be pressed
        AddButton = view.findViewById(R.id.add_product);
        AddButton.setOnClickListener(this);

        //listens for view button to be pressed
        ViewButton = view.findViewById(R.id.view_products);
        ViewButton.setOnClickListener(this);

        //listens for delete button to be pressed
        DeleteButton = view.findViewById(R.id.delete_product);
        DeleteButton.setOnClickListener(this);

        //listens for update button to be pressed
        UpdateButton = view.findViewById(R.id.update_product);
        UpdateButton.setOnClickListener(this);

        return view;
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()) //switch statement for triggering the different fragments for each button
        {
            case R.id.add_product:
                MainActivity.fragmentManager.beginTransaction().replace(R.id.fragment_container,new AddProductFragment())
                        .addToBackStack(null).commit();
                break;

            case R.id.view_products:
                MainActivity.fragmentManager.beginTransaction().replace(R.id.fragment_container,new ReadProductFragment())
                        .addToBackStack(null).commit();
                break;

            case R.id.delete_product:
                MainActivity.fragmentManager.beginTransaction().replace(R.id.fragment_container,new DeleteProductFragment())
                        .addToBackStack(null).commit();
                break;

            case R.id.update_product:
                MainActivity.fragmentManager.beginTransaction().replace(R.id.fragment_container,new UpdateFragment())
                        .addToBackStack(null).commit();
                break;
        }
    }
}
