package com.example.unkno_000.finaldatabase;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class ReadProductFragment extends Fragment {
    private TextView Txtinfo;

    public ReadProductFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_read_product, container, false);
        Txtinfo = view.findViewById(R.id.read_info);

        List<Product> products = MainActivity.productDatabase.productDao().getProducts();

        String info = "";

        for(Product product :products){
            String item = product.getItem();
            int itemNumber = product.getItemNumber();
            float itemPrice = product.getPrice();
            int itemquantity = product.getQuantity();
            int itemexpDate = product.getExpData();

            info = info+"\n\n"+"Item :"+item+"\n Item Number :"+itemNumber+"\n Price :"+itemPrice
                    +"\n Quantity :"+itemquantity+"\n Expiration Date :"+itemexpDate;
        }

        Txtinfo.setText(info);
        return view;
    }

}
