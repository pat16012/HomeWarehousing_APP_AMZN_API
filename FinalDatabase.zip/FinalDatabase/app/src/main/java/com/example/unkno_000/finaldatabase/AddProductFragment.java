package com.example.unkno_000.finaldatabase;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class AddProductFragment extends Fragment {

    private EditText ProductName,ProductNumber,ProductPrice,ProductQuantity,ProductExpDate;

    private Button ButtonSave;


    public AddProductFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_add_product, container, false);

        ProductName = view.findViewById(R.id.add_item);
        ProductNumber = view.findViewById(R.id.add_item_number);
        ProductPrice = view.findViewById(R.id.add_item_price);
        ProductQuantity = view.findViewById(R.id.add_item_quantity);
        ProductExpDate = view.findViewById(R.id.add_item_expDate);
        ButtonSave = view.findViewById(R.id.save_product);

        ButtonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String productname = ProductName.getText().toString();
                int productnumber = Integer.parseInt(ProductNumber.getText().toString());
                float productprice = Float.parseFloat(ProductPrice.getText().toString());
                int productquantity = Integer.parseInt(ProductQuantity.getText().toString());
                int productexpdate = Integer.parseInt(ProductExpDate.getText().toString());

                Product product = new Product();
                product.setItem(productname);
                product.setItemNumber(productnumber);
                product.setPrice(productprice);
                product.setQuantity(productquantity);
                product.setExpData(productexpdate);

                MainActivity.productDatabase.productDao().addProduct(product);
                Toast.makeText(getActivity(),"Product added successfully",Toast.LENGTH_SHORT).show();

                ProductName.setText("");
                ProductNumber.setText("");
                ProductPrice.setText("");
                ProductQuantity.setText("");
                ProductExpDate.setText("");
            }
        });

        return view;
    }

}
