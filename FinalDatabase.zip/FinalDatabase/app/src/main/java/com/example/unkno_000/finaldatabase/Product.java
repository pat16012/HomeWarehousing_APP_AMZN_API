package com.example.unkno_000.finaldatabase;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
//this is the object that is being used with the database.
@Entity(tableName = "products")
public class Product {
    private String item;

    @PrimaryKey //this in room identifies this as the main identifier
    private int itemNumber;

    private float price;

    private int quantity;

    private int expData; //I'm assuming this is just gonna be in a MMDDYY or MMDDYYYY format

    //Getters and setters must be established
    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public int getItemNumber() {
        return itemNumber;
    }

    public void setItemNumber(int itemNumber) {
        this.itemNumber = itemNumber;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getExpData() {
        return expData;
    }

    public void setExpData(int expData) {
        this.expData = expData;
    }
}
