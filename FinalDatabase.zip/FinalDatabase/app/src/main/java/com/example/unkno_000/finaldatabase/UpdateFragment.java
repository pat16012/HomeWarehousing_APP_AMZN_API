package com.example.unkno_000.finaldatabase;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

//This is here to create the update page
/**
 * A simple {@link Fragment} subclass.
 */
public class UpdateFragment extends Fragment {
    private EditText ProductName,ProductNumber,ProductPrice,ProductQuantity,ProductExpDate;
    private Button UpdateButton;

    public UpdateFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_update, container, false);
        //sets variables within this class to connect with inputs and buttons on update screen
        ProductName = view.findViewById(R.id.update_item_name);
        ProductNumber = view.findViewById(R.id.update_item_number);
        ProductPrice = view.findViewById(R.id.update_item_price);
        ProductQuantity = view.findViewById(R.id.update_item_quantity);
        ProductExpDate = view.findViewById(R.id.update_item_expDate);
        UpdateButton = view.findViewById(R.id.update_button);

        UpdateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //sets variables to read the values places in the user inputs
                String name = ProductName.getText().toString();
                int number = Integer.parseInt(ProductNumber.getText().toString());
                float price = Float.parseFloat(ProductPrice.getText().toString());
                int quantity = Integer.parseInt(ProductQuantity.getText().toString());
                int expDate = Integer.parseInt(ProductExpDate.getText().toString());

                //creates replacement inputs for the update
                Product product = new Product();
                product.setItem(name);
                product.setItemNumber(number);
                product.setPrice(price);
                product.setQuantity(quantity);
                product.setExpData(expDate);

                //clarifies that the product has been updatesd and displays
                MainActivity.productDatabase.productDao().updateProduct(product);
                Toast.makeText(getActivity(),"Product Updated...", Toast.LENGTH_SHORT).show();
                ProductName.setText("");
                ProductNumber.setText("");
                ProductPrice.setText("");
                ProductQuantity.setText("");
                ProductExpDate.setText("");
            }
        });
        return view;
    }

}
