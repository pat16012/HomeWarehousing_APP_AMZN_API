package com.example.unkno_000.finaldatabase;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.util.List;

//allows access to the database
@Dao
public interface ProductDao {

    @Insert //adds to database
    public void addProduct(Product product);

    @Query("select * from products") //looks at database
    public List<Product> getProducts();

    @Delete //deletes content in database
    public void deleteProduct(Product product);

    @Update //updates an entries already in database
    public void updateProduct(Product product);

}
