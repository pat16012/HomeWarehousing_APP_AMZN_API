package com.example.unkno_000.finaldatabase;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;

//the database itself, no need to update this
@Database(entities = {Product.class},version = 1)
public abstract class ProductDatabase extends RoomDatabase {
    public abstract ProductDao productDao();
}
